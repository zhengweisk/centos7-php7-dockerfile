#!/bin/bash
mysql -e "CREATE DATABASE IF NOT EXISTS test"
